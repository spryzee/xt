
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";

interface UserFileEditorProps {
  username: string;
  content: string;
  onContentChange: (content: string) => void;
  onSave: () => void;
  isLoading?: boolean;
}

const UserFileEditor: React.FC<UserFileEditorProps> = ({
  username,
  content,
  onContentChange,
  onSave,
  isLoading = false
}) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">{username}.py</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="h-64 animate-pulse">
            <div className="h-full bg-secondary/20 rounded-md"></div>
          </div>
        ) : (
          <>
            <Textarea
              value={content}
              onChange={(e) => onContentChange(e.target.value)}
              className="font-mono text-sm h-64 bg-secondary/20"
            />
            <div className="mt-4 flex justify-end">
              <Button onClick={onSave}>Save Changes</Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
};

export default UserFileEditor;
