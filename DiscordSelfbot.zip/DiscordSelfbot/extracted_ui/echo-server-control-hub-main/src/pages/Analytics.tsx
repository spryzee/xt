
import { useEffect, useState } from "react";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Mock data for demonstration
const generateData = (days: number, baseline: number, variance: number) => {
  return Array.from({ length: days }).map((_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (days - 1 - i));
    const formattedDate = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    
    return {
      date: formattedDate,
      users: Math.floor(baseline + Math.random() * variance),
      commands: Math.floor((baseline * 10) + Math.random() * (variance * 10)),
      messages: Math.floor((baseline * 40) + Math.random() * (variance * 40)),
    };
  });
};

export default function Analytics() {
  const [timeRange, setTimeRange] = useState("7d");
  const [analyticsData, setAnalyticsData] = useState<any[]>([]);
  
  useEffect(() => {
    // Generate data based on the selected time range
    if (timeRange === "7d") {
      setAnalyticsData(generateData(7, 50, 30));
    } else if (timeRange === "14d") {
      setAnalyticsData(generateData(14, 45, 35));
    } else if (timeRange === "30d") {
      setAnalyticsData(generateData(30, 40, 40));
    }
  }, [timeRange]);

  return (
    <div className="space-y-6 pb-8">
      <div className="animate-fade-in">
        <h1 className="text-3xl font-bold tracking-tight">Analytics</h1>
        <p className="text-muted-foreground">Track user engagement and bot performance.</p>
      </div>

      <Tabs defaultValue="7d" value={timeRange} onValueChange={setTimeRange} className="animate-fade-in" style={{animationDelay: "100ms"}}>
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">Usage Metrics</h2>
          <TabsList>
            <TabsTrigger value="7d">7 Days</TabsTrigger>
            <TabsTrigger value="14d">14 Days</TabsTrigger>
            <TabsTrigger value="30d">30 Days</TabsTrigger>
          </TabsList>
        </div>
        
        <TabsContent value={timeRange} className="space-y-4 mt-4">
          <Card>
            <CardHeader>
              <CardTitle>User Engagement</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[350px]">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={analyticsData} margin={{ top: 10, right: 30, left: 0, bottom: 5 }}>
                    <defs>
                      <linearGradient id="colorUsers" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8884d8" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#8884d8" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorCommands" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#82ca9d" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#82ca9d" stopOpacity={0}/>
                      </linearGradient>
                      <linearGradient id="colorMessages" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#ffc658" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#ffc658" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="date" />
                    <YAxis />
                    <CartesianGrid strokeDasharray="3 3" />
                    <Tooltip />
                    <Area type="monotone" dataKey="users" stroke="#8884d8" fillOpacity={1} fill="url(#colorUsers)" />
                    <Area type="monotone" dataKey="commands" stroke="#82ca9d" fillOpacity={1} fill="url(#colorCommands)" />
                    <Area type="monotone" dataKey="messages" stroke="#ffc658" fillOpacity={1} fill="url(#colorMessages)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
              <div className="flex items-center justify-center gap-4 mt-4">
                <div className="flex items-center">
                  <span className="w-3 h-3 rounded-full bg-[#8884d8] mr-2"></span>
                  <span className="text-sm">Users</span>
                </div>
                <div className="flex items-center">
                  <span className="w-3 h-3 rounded-full bg-[#82ca9d] mr-2"></span>
                  <span className="text-sm">Commands</span>
                </div>
                <div className="flex items-center">
                  <span className="w-3 h-3 rounded-full bg-[#ffc658] mr-2"></span>
                  <span className="text-sm">Messages</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <div className="grid gap-4 md:grid-cols-2 animate-fade-in" style={{animationDelay: "200ms"}}>
        <Card>
          <CardHeader>
            <CardTitle>Top Commands</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {[
                { name: "!help", usage: "12,845", growth: "+8%" },
                { name: "!play", usage: "8,721", growth: "+15%" },
                { name: "!ban", usage: "3,254", growth: "-2%" },
                { name: "!mute", usage: "2,987", growth: "+5%" },
                { name: "!stats", usage: "2,145", growth: "+22%" }
              ].map((command, i) => (
                <div key={i} className="flex items-center justify-between py-2 border-b last:border-0">
                  <span className="font-medium">{command.name}</span>
                  <div className="flex items-center gap-3">
                    <span>{command.usage}</span>
                    <span className={command.growth.startsWith("+") ? "text-green-500" : "text-red-500"}>
                      {command.growth}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardHeader>
            <CardTitle>Server Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {[
                { name: "Gaming HQ", messages: "45,823", users: "1,482" },
                { name: "Music Bot", messages: "12,387", users: "223" },
                { name: "Community", messages: "38,945", users: "3,241" },
                { name: "Dev Team", messages: "5,214", users: "57" },
                { name: "Support Server", messages: "28,754", users: "2,165" }
              ].map((server, i) => (
                <div key={i} className="flex items-center justify-between py-2 border-b last:border-0">
                  <span className="font-medium">{server.name}</span>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground">{server.messages} msgs</span>
                    <span className="text-sm text-muted-foreground">{server.users} users</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
