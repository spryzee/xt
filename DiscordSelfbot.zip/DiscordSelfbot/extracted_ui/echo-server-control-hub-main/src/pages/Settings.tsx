
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { useState } from "react";
import { toast } from "sonner";
import { Cog, Save, RefreshCw } from "lucide-react";

export default function Settings() {
  const [autoReconnect, setAutoReconnect] = useState(true);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [proxyUrl, setProxyUrl] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  const handleSaveSettings = () => {
    setIsSaving(true);
    
    // Simulate saving settings
    setTimeout(() => {
      // Save settings to localStorage
      localStorage.setItem("settings", JSON.stringify({
        autoReconnect,
        notificationsEnabled,
        proxyUrl
      }));
      
      toast.success("Settings saved successfully");
      setIsSaving(false);
    }, 800);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Settings</h1>
        <Button onClick={handleSaveSettings} disabled={isSaving}>
          {isSaving ? (
            <>
              <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              Saving...
            </>
          ) : (
            <>
              <Save className="mr-2 h-4 w-4" />
              Save Settings
            </>
          )}
        </Button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="glass">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Cog className="mr-2" size={18} />
              General Settings
            </CardTitle>
            <CardDescription>Configure general application settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="auto-reconnect">Auto Reconnect</Label>
                <p className="text-sm text-muted-foreground">
                  Automatically reconnect accounts if they go offline
                </p>
              </div>
              <Switch 
                id="auto-reconnect"
                checked={autoReconnect}
                onCheckedChange={setAutoReconnect}
              />
            </div>
            
            <Separator />
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="notifications">Notifications</Label>
                <p className="text-sm text-muted-foreground">
                  Receive notifications for important events
                </p>
              </div>
              <Switch 
                id="notifications"
                checked={notificationsEnabled}
                onCheckedChange={setNotificationsEnabled}
              />
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <Label htmlFor="proxy-url">Proxy URL (Optional)</Label>
              <Input 
                id="proxy-url"
                placeholder="http://proxy.example.com:8080" 
                value={proxyUrl}
                onChange={(e) => setProxyUrl(e.target.value)}
              />
              <p className="text-xs text-muted-foreground">
                Enter a proxy URL if you need to route connections through a proxy
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="glass">
          <CardHeader>
            <CardTitle>Developer Options</CardTitle>
            <CardDescription>Advanced settings for developers</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="debug-mode">Debug Mode</Label>
                <p className="text-sm text-muted-foreground">
                  Automatically reconnect accounts if they go offline
                </p>
              </div>
              <Switch id="debug-mode" />
            </div>
            
            <Separator />
            
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="api-access">API Access</Label>
                <p className="text-sm text-muted-foreground">
                  Allow external API access to the application
                </p>
              </div>
              <Switch id="api-access" />
            </div>
            
            <Separator />
            
            <Button variant="outline" className="w-full">
              Reset to Default Settings
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
