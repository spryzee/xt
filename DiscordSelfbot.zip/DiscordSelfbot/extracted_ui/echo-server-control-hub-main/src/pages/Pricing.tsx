
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Check } from "lucide-react";

interface PricingPlanProps {
  name: string;
  description: string;
  price: string;
  features: string[];
  isPopular?: boolean;
  buttonText?: string;
}

const PricingPlan = ({ name, description, price, features, isPopular, buttonText = "Get Started" }: PricingPlanProps) => {
  return (
    <Card className={`flex flex-col card-hover ${isPopular ? 'border-primary shadow-lg shadow-primary/20' : ''}`}>
      <CardHeader>
        {isPopular && (
          <div className="py-1 px-3 rounded-full text-xs font-semibold bg-primary text-white w-fit mb-2">
            MOST POPULAR
          </div>
        )}
        <CardTitle>{name}</CardTitle>
        <CardDescription>{description}</CardDescription>
      </CardHeader>
      <CardContent className="flex-1">
        <div className="mb-4">
          <span className="text-3xl font-bold">{price}</span>
          {price !== "Free" && <span className="text-muted-foreground">/month</span>}
        </div>
        
        <ul className="space-y-2.5">
          {features.map((feature, index) => (
            <li key={index} className="flex items-start">
              <Check className="mr-2 h-4 w-4 mt-0.5 text-primary" />
              <span className="text-sm">{feature}</span>
            </li>
          ))}
        </ul>
      </CardContent>
      <CardFooter>
        <Button className={`w-full ${isPopular ? '' : 'bg-secondary hover:bg-secondary/80'}`}>
          {buttonText}
        </Button>
      </CardFooter>
    </Card>
  )
}

export default function Pricing() {
  return (
    <div className="space-y-10 pb-8">
      <div className="space-y-4 text-center animate-fade-in">
        <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">Pricing Plans</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Choose the perfect plan for your needs. All plans include a 14-day free trial with no credit card required.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 animate-fade-in" style={{animationDelay: "100ms"}}>
        <PricingPlan 
          name="Free"
          description="Perfect for testing and small projects"
          price="Free"
          features={[
            "Connect 1 Discord bot",
            "Up to 3 servers",
            "Basic bot commands",
            "Standard uptime monitoring",
            "Community support"
          ]}
          buttonText="Start Free"
        />
        
        <PricingPlan 
          name="Pro"
          description="Great for growing communities"
          price="$15"
          features={[
            "Connect 3 Discord bots",
            "Up to 10 servers",
            "Advanced bot commands",
            "Detailed analytics",
            "Priority uptime monitoring",
            "Email + chat support"
          ]}
          isPopular={true}
        />
        
        <PricingPlan 
          name="Enterprise"
          description="For large communities and businesses"
          price="$49"
          features={[
            "Unlimited Discord bots",
            "Unlimited servers",
            "Custom bot development",
            "Advanced analytics & reporting",
            "99.9% uptime SLA",
            "24/7 priority support",
            "Dedicated account manager"
          ]}
          buttonText="Contact Sales"
        />
      </div>
      
      <div className="mt-16 text-center animate-fade-in" style={{animationDelay: "200ms"}}>
        <h2 className="text-xl font-semibold mb-2">Need a custom solution?</h2>
        <p className="text-muted-foreground mb-4">
          Contact our sales team for a quote on custom-built bots and enterprise integrations.
        </p>
        <Button variant="outline">Contact Sales</Button>
      </div>
    </div>
  )
}
