
// Discord account management utilities
import { toast } from "sonner";
import { mkdir, writeFile, readFile } from "@/utils/fileSystem";

// Interface for Discord account
export interface DiscordAccount {
  id: string;
  username: string;
  token: string;
  avatar: string;
  status: "online" | "idle" | "offline";
  servers: number;
  lastActive: string;
}

// Function to create a Discord script file
export const createDiscordScript = (username: string, token: string): string => {
  return `import discord
import asyncio
import logging
from colorama import Fore, Style

# Enable logging
logging.basicConfig(level=logging.INFO)

# List of account tokens
TOKENS = [
  "${token}"
]

# Define a function to run a selfbot instance
async def run_selfbot(token):
    intents = discord.Intents.all()
    client = discord.Client(intents=intents)

    @client.event
    async def on_ready():
        print(Fore.GREEN + f"Logged in as {client.user} ({client.user.id})" + Style.RESET_ALL)

    @client.event
    async def on_message(message):
        if message.author.id != client.user.id:
            return  # Ignore messages from others

        if message.content.startswith("!ping"):
            await message.channel.send("Pong!")

    try:
        await client.start(token, bot=False)
    except discord.errors.LoginFailure:
        print(Fore.RED + f"Invalid token: {token[:10]}..." + Style.RESET_ALL)
    except Exception as e:
        print(Fore.RED + f"Error: {e}" + Style.RESET_ALL)

# Run all accounts concurrently
async def main():
    tasks = [run_selfbot(token) for token in TOKENS]
    await asyncio.gather(*tasks)

if __name__ == "__main__":
    asyncio.run(main())
`;
};

// Function to get account file content
export const getAccountFile = async (username: string): Promise<string> => {
  try {
    const content = await readFile(`/user/${username}.py`);
    return content;
  } catch (error) {
    console.error(`Error reading file for ${username}:`, error);
    return createDiscordScript(username, "TOKEN_NOT_ACCESSIBLE");
  }
};

// Function to save account file content
export const saveAccountFile = async (username: string, content: string): Promise<void> => {
  try {
    await writeFile(`/user/${username}.py`, content);
    console.log(`Updated Python file: /user/${username}.py`);
    return Promise.resolve();
  } catch (error) {
    console.error(`Error saving file for ${username}:`, error);
    throw error;
  }
};

// Function to save account to localStorage and create Python file
export const saveDiscordAccount = async (username: string, token: string): Promise<DiscordAccount> => {
  try {
    // Check if we've reached the 5 account limit
    const existingAccounts = getDiscordAccounts();
    if (existingAccounts.length >= 5) {
      throw new Error("Maximum limit of 5 accounts reached");
    }
    
    // Create user directory if it doesn't exist and write Python file
    try {
      await mkdir("/user");
      const scriptContent = createDiscordScript(username, token);
      await writeFile(`/user/${username}.py`, scriptContent);
      console.log(`Created Python file: /user/${username}.py`);
    } catch (error) {
      console.error("Error creating Python file:", error);
      // Continue anyway as this is just a demo
    }
    
    // Generate a unique ID
    const id = Date.now().toString();
    
    // Create the account object
    const account: DiscordAccount = {
      id,
      username,
      token,
      avatar: "",
      status: "online", // New accounts start as online
      servers: Math.floor(Math.random() * 5) + 1, // Random number of servers
      lastActive: "just now"
    };
    
    // Get existing accounts
    const accounts = existingAccounts;
    
    // Add the new account
    accounts.push(account);
    
    // Save back to localStorage
    localStorage.setItem("discord_users", JSON.stringify(accounts));
    
    // Dispatch event to notify listeners
    window.dispatchEvent(new CustomEvent("account-added"));
    
    return account;
  } catch (error) {
    console.error("Error saving account:", error);
    throw error;
  }
};

// Function to get all accounts
export const getDiscordAccounts = (): DiscordAccount[] => {
  const accounts = localStorage.getItem("discord_users");
  return accounts ? JSON.parse(accounts) : [];
};

// Function to toggle account status
export const toggleAccountStatus = (id: string): void => {
  const accounts = getDiscordAccounts();
  const accountIndex = accounts.findIndex(acc => acc.id === id);
  
  if (accountIndex !== -1) {
    // Toggle status
    const currentStatus = accounts[accountIndex].status;
    accounts[accountIndex].status = currentStatus === "online" ? "offline" : "online";
    
    // Update lastActive
    accounts[accountIndex].lastActive = "just now";
    
    // Save back to localStorage
    localStorage.setItem("discord_users", JSON.stringify(accounts));
    
    // Dispatch event to notify listeners
    window.dispatchEvent(new CustomEvent("account-updated"));
  }
};

// Function to remove Discord account
export const removeDiscordAccount = (id: string): void => {
  try {
    // Get existing accounts
    const accounts = getDiscordAccounts();
    
    // Find the account to delete
    const accountIndex = accounts.findIndex(acc => acc.id === id);
    if (accountIndex === -1) {
      toast.error("Account not found");
      return;
    }
    
    // Get the username to delete the Python file (in a real implementation)
    const username = accounts[accountIndex].username;
    console.log(`Would delete Python file for: ${username}`);
    
    // Remove from accounts array
    accounts.splice(accountIndex, 1);
    
    // Save back to localStorage
    localStorage.setItem("discord_users", JSON.stringify(accounts));
    
    // Notify listeners
    window.dispatchEvent(new CustomEvent("account-removed"));
    
    toast.success("Account removed successfully");
  } catch (error) {
    console.error("Error removing account:", error);
    toast.error("Failed to remove account");
  }
};
