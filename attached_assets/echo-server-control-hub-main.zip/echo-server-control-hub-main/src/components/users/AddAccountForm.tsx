
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { saveDiscordAccount } from "@/utils/discord";
import { AlertCircle } from "lucide-react";

interface AddAccountFormProps {
  maxAccounts?: number;
  currentCount?: number;
}

export function AddAccountForm({ maxAccounts = 5, currentCount = 0 }: AddAccountFormProps) {
  const [token, setToken] = useState("");
  const [username, setUsername] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleAddAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!token.trim()) {
      toast.error("Please enter a valid Discord token");
      return;
    }
    
    if (!username.trim()) {
      toast.error("Please enter a username");
      return;
    }
    
    if (currentCount >= maxAccounts) {
      toast.error(`Maximum limit of ${maxAccounts} accounts reached`);
      return;
    }
    
    setIsLoading(true);
    
    try {
      // Save the account to our backend
      await saveDiscordAccount(username, token);
      
      // Reset form
      setToken("");
      setUsername("");
    } catch (error: any) {
      toast.error(error?.message || "Failed to add account. Please try again.");
      console.error("Error adding account:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const isLimitReached = currentCount >= maxAccounts;

  return (
    <Card className="glass">
      <CardHeader>
        <CardTitle className="text-xl">Add Discord Account</CardTitle>
      </CardHeader>
      <CardContent>
        {isLimitReached ? (
          <div className="p-4 border border-yellow-500/20 bg-yellow-500/10 rounded-md flex items-start gap-3">
            <AlertCircle className="text-yellow-500 mt-0.5" size={18} />
            <div>
              <p className="text-sm font-medium text-yellow-500">Account Limit Reached</p>
              <p className="text-xs mt-1 text-muted-foreground">
                You've reached the maximum limit of {maxAccounts} accounts. 
                Remove an existing account before adding a new one.
              </p>
            </div>
          </div>
        ) : (
          <form onSubmit={handleAddAccount} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username</Label>
              <Input 
                id="username"
                placeholder="Enter username" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                disabled={isLoading || isLimitReached}
                className="bg-background/50"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="token">Discord Token</Label>
              <Input 
                id="token"
                type="password" 
                placeholder="Enter Discord token" 
                value={token}
                onChange={(e) => setToken(e.target.value)}
                disabled={isLoading || isLimitReached}
                className="bg-background/50"
              />
              <p className="text-xs text-muted-foreground">
                Your token is stored securely and used to run your Discord account.
              </p>
            </div>
            
            <Button 
              type="submit" 
              className="w-full" 
              disabled={isLoading || isLimitReached}
              variant="default"
            >
              {isLoading ? "Adding Account..." : "Add Account"}
            </Button>
            
            <div className="text-xs text-center text-muted-foreground">
              {currentCount}/{maxAccounts} accounts used
            </div>
          </form>
        )}
      </CardContent>
    </Card>
  );
}
