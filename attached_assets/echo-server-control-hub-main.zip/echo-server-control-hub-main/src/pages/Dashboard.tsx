
import { BarChart, Bot, Server, Users } from "lucide-react";
import StatsCard from "@/components/dashboard/StatsCard";
import ServerStatusCard from "@/components/dashboard/ServerStatusCard";
import UptimeGraph from "@/components/dashboard/UptimeGraph";
import RecentActivity from "@/components/dashboard/RecentActivity";
import { useQuery } from "@tanstack/react-query";
import { getDiscordAccounts } from "@/utils/discord";

export default function Dashboard() {
  const { data: accounts = [] } = useQuery({
    queryKey: ['users'],
    queryFn: getDiscordAccounts
  });

  // Calculate real stats based on actual accounts
  const totalAccounts = accounts.length;
  const onlineAccounts = accounts.filter(acc => acc.status === "online").length;
  const totalServers = accounts.reduce((sum, acc) => sum + acc.servers, 0);

  return (
    <div className="space-y-6 pb-8">
      <div className="animate-fade-in">
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Monitor and manage your Discord bots and servers.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 animate-fade-in" style={{animationDelay: "100ms"}}>
        <StatsCard 
          title="Total Accounts"
          value={totalAccounts.toString()}
          icon={<Server size={18} />}
          description="Currently registered"
        />
        <StatsCard 
          title="Online Accounts"
          value={onlineAccounts.toString()}
          icon={<Bot size={18} />}
          trend={{ value: onlineAccounts > 0 ? Math.round((onlineAccounts / totalAccounts) * 100) : 0, isPositive: true }}
          description="Active right now"
        />
        <StatsCard 
          title="Total Servers"
          value={totalServers.toString()}
          icon={<Users size={18} />}
          description="Across all accounts"
        />
        <StatsCard 
          title="Available Slots"
          value={(5 - totalAccounts).toString()}
          icon={<BarChart size={18} />}
          description="Accounts you can add"
        />
      </div>

      <div className="grid gap-4 md:grid-cols-2 animate-fade-in" style={{animationDelay: "200ms"}}>
        <UptimeGraph />
        <RecentActivity />
      </div>

      {accounts.length > 0 && (
        <>
          <h2 className="text-xl font-semibold mt-8 animate-fade-in" style={{animationDelay: "300ms"}}>Account Status</h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 animate-fade-in" style={{animationDelay: "300ms"}}>
            {accounts.map((account) => (
              <ServerStatusCard 
                key={account.id} 
                server={{
                  id: account.id,
                  name: account.username,
                  status: account.status,
                  uptime: account.lastActive,
                  users: account.servers,
                  region: "Global"
                }} 
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
