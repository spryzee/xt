
import { AddAccountForm } from "@/components/users/AddAccountForm";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { getDiscordAccounts, toggleAccountStatus, removeDiscordAccount, getAccountFile, saveAccountFile } from "@/utils/discord";
import { Button } from "@/components/ui/button";
import { PowerOff, Power, Trash2, AlertTriangle, FileText, Edit } from "lucide-react";
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import UserFileEditor from "@/components/users/UserFileEditor";

// Types for user data
interface User {
  id: string;
  username: string;
  avatar: string;
  status: "online" | "idle" | "offline";
  servers: number;
  lastActive: string;
}

export default function Users() {
  // Use React Query for better data fetching
  const { data: users = [], isLoading, error, refetch } = useQuery({
    queryKey: ['users'],
    queryFn: getDiscordAccounts
  });
  
  // State for deletion confirmation
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [accountToDelete, setAccountToDelete] = useState<string | null>(null);
  
  // State for file editor
  const [fileEditorOpen, setFileEditorOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [fileContent, setFileContent] = useState<string>("");
  const [isFileLoading, setIsFileLoading] = useState(false);

  // Listen for storage events to update users list (simulating real-time updates)
  useEffect(() => {
    // Initialize localStorage if empty
    if (!localStorage.getItem("discord_users")) {
      localStorage.setItem("discord_users", JSON.stringify([]));
    }
    
    // Define custom event handlers for account changes
    const handleAccountAdded = () => {
      refetch();
      toast.success("Account added successfully");
    };
    
    const handleAccountUpdated = () => {
      refetch();
    };
    
    const handleAccountRemoved = () => {
      refetch();
    };
    
    // Add event listeners
    window.addEventListener("account-added", handleAccountAdded);
    window.addEventListener("account-updated", handleAccountUpdated);
    window.addEventListener("account-removed", handleAccountRemoved);
    
    return () => {
      window.removeEventListener("account-added", handleAccountAdded);
      window.removeEventListener("account-updated", handleAccountUpdated);
      window.removeEventListener("account-removed", handleAccountRemoved);
    };
  }, [refetch]);
  
  // Check for error state
  useEffect(() => {
    if (error) {
      toast.error("Failed to load user accounts");
      console.error("Error loading users:", error);
    }
  }, [error]);
  
  // Handle toggling account status
  const handleToggleStatus = (id: string) => {
    toggleAccountStatus(id);
  };
  
  // Handle account deletion
  const handleDeleteClick = (id: string) => {
    setAccountToDelete(id);
    setDeleteConfirmOpen(true);
  };
  
  const confirmDelete = () => {
    if (accountToDelete) {
      removeDiscordAccount(accountToDelete);
      setAccountToDelete(null);
    }
    setDeleteConfirmOpen(false);
  };
  
  // Handle file viewing/editing
  const handleViewFile = async (user: User) => {
    setCurrentUser(user);
    setIsFileLoading(true);
    try {
      const content = await getAccountFile(user.username);
      setFileContent(content);
      setFileEditorOpen(true);
    } catch (err) {
      toast.error("Failed to load file content");
      console.error(err);
    } finally {
      setIsFileLoading(false);
    }
  };
  
  const handleSaveFile = async () => {
    if (currentUser) {
      try {
        await saveAccountFile(currentUser.username, fileContent);
        toast.success("File saved successfully");
        setFileEditorOpen(false);
      } catch (err) {
        toast.error("Failed to save file");
        console.error(err);
      }
    }
  };
  
  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Account Management</h1>
        <div className="text-sm text-muted-foreground">
          {users.length}/5 accounts used
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Add Account Form */}
        <div className="md:col-span-1">
          <AddAccountForm maxAccounts={5} currentCount={users.length} />
        </div>
        
        {/* User List */}
        <div className="md:col-span-2">
          <Card className="glass">
            <CardHeader>
              <CardTitle>Managed Accounts</CardTitle>
              <CardDescription>Discord accounts managed by XTLive</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex justify-center items-center py-8">
                  <div className="animate-pulse flex space-x-4 w-full">
                    <div className="rounded-full bg-secondary h-12 w-12"></div>
                    <div className="flex-1 space-y-4 py-1">
                      <div className="h-4 bg-secondary rounded w-3/4"></div>
                      <div className="h-3 bg-secondary rounded w-5/6"></div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {users.map(user => (
                    <div 
                      key={user.id}
                      className="flex items-center justify-between p-4 rounded-md bg-secondary/50 hover:bg-secondary transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <Avatar>
                          <AvatarImage src={user.avatar || ""} />
                          <AvatarFallback>{user.username.substring(0, 2).toUpperCase()}</AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">{user.username}</p>
                          <p className="text-xs text-muted-foreground">{user.servers} servers • {user.lastActive}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-2 mr-2">
                          <div className={`w-2 h-2 rounded-full ${
                            user.status === "online" ? "bg-green-500" : 
                            user.status === "idle" ? "bg-yellow-500" : 
                            "bg-gray-500"
                          }`} />
                          <span className="text-sm capitalize hidden sm:inline">{user.status}</span>
                        </div>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => handleViewFile(user)}
                          className="mr-1"
                          title="View Python File"
                        >
                          <FileText size={16} className="text-blue-500" />
                        </Button>
                        <Button 
                          size="sm" 
                          variant={user.status === "online" ? "destructive" : "default"}
                          onClick={() => handleToggleStatus(user.id)}
                          className="mr-1"
                        >
                          {user.status === "online" ? (
                            <>
                              <PowerOff size={16} className="mr-1" />
                              <span className="hidden sm:inline">Take Offline</span>
                            </>
                          ) : (
                            <>
                              <Power size={16} className="mr-1" />
                              <span className="hidden sm:inline">Go Online</span>
                            </>
                          )}
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDeleteClick(user.id)}
                        >
                          <Trash2 size={16} className="text-red-500" />
                        </Button>
                      </div>
                    </div>
                  ))}
                  
                  {users.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      No accounts added yet
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
          
          {/* Instructions Card */}
          <Card className="glass mt-6">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <AlertTriangle size={18} className="text-yellow-500" />
                Important Information
              </CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              <p className="mb-2">• Python files are created in the user folder when you add an account.</p>
              <p className="mb-2">• Maximum of 5 accounts can be added per user.</p>
              <p className="mb-2">• Tokens are stored securely and used to authenticate your Discord account.</p>
              <p>• Script files are named after the username you provide (e.g., username.py).</p>
            </CardContent>
          </Card>
        </div>
      </div>
      
      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteConfirmOpen} onOpenChange={setDeleteConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the account
              and remove the associated Python file.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* File Editor Dialog */}
      <Dialog open={fileEditorOpen} onOpenChange={setFileEditorOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <FileText size={18} />
              {currentUser?.username}.py
            </DialogTitle>
            <DialogDescription>
              View and edit the Python script for this Discord account
            </DialogDescription>
          </DialogHeader>
          
          {isFileLoading ? (
            <div className="h-64 flex items-center justify-center">
              <div className="animate-pulse flex space-x-4 w-full">
                <div className="flex-1 space-y-4 py-1">
                  <div className="h-4 bg-secondary rounded w-3/4"></div>
                  <div className="h-4 bg-secondary rounded"></div>
                  <div className="h-4 bg-secondary rounded w-5/6"></div>
                  <div className="h-4 bg-secondary rounded w-1/2"></div>
                </div>
              </div>
            </div>
          ) : (
            <div className="border rounded-md">
              <Textarea 
                value={fileContent} 
                onChange={(e) => setFileContent(e.target.value)}
                className="font-mono text-sm h-64 bg-secondary/20"
              />
            </div>
          )}
          
          <DialogFooter>
            <Button variant="outline" onClick={() => setFileEditorOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveFile}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
